<?php

return [
    'name' => 'Expertise',
];
