<?php

return [
    'name' => 'PortfolioImages',
];
