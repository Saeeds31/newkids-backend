<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {

        Schema::table('categories', function (Blueprint $table) {
            $table->boolean('show_in_home')->default(false);
            $table->boolean('show_products_in_home')->default(false);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void {}
};
