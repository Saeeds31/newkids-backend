<?php

return [
    'name' => 'Orders',
];
