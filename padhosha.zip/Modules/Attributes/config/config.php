<?php

return [
    'name' => 'Attributes',
];
