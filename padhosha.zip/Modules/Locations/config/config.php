<?php

return [
    'name' => 'Locations',
];
