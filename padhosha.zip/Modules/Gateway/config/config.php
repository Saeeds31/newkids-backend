<?php

return [
    'name' => 'Gateway',
];
