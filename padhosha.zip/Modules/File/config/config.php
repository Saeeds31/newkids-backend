<?php

return [
    'name' => 'File',
];
